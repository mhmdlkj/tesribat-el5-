"use client"

import { useState, useEffect } from "react"
import { Search, SlidersHorizontal, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"

// Sample product data
const products = [
  {
    id: 1,
    name: "Minimalist Ceramic Vase",
    price: 39.99,
    rating: 4.5,
    category: "Home Decor",
    color: "White",
    brand: "Nordic Living",
    image: "/placeholder.svg?height=300&width=300",
    isNew: true,
  },
  {
    id: 2,
    name: "Organic Cotton T-Shirt",
    price: 24.99,
    rating: 4.2,
    category: "Clothing",
    color: "Black",
    brand: "EcoWear",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 3,
    name: "Wireless Noise-Cancelling Headphones",
    price: 199.99,
    rating: 4.8,
    category: "Electronics",
    color: "Silver",
    brand: "SoundWave",
    image: "/placeholder.svg?height=300&width=300",
    isNew: true,
  },
  {
    id: 4,
    name: "Leather Crossbody Bag",
    price: 89.99,
    rating: 4.3,
    category: "Accessories",
    color: "Brown",
    brand: "Urban Style",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 5,
    name: "Smart Fitness Watch",
    price: 149.99,
    rating: 4.6,
    category: "Electronics",
    color: "Black",
    brand: "TechFit",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 6,
    name: "Scented Soy Candle",
    price: 19.99,
    rating: 4.4,
    category: "Home Decor",
    color: "Beige",
    brand: "Serene Home",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    id: 7,
    name: "Stainless Steel Water Bottle",
    price: 29.99,
    rating: 4.7,
    category: "Kitchenware",
    color: "Blue",
    brand: "EcoHydrate",
    image: "/placeholder.svg?height=300&width=300",
    isNew: true,
  },
  {
    id: 8,
    name: "Handcrafted Ceramic Mug",
    price: 14.99,
    rating: 4.1,
    category: "Kitchenware",
    color: "Gray",
    brand: "Artisan Crafts",
    image: "/placeholder.svg?height=300&width=300",
  },
]

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [priceRange, setPriceRange] = useState([0, 200])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [selectedBrands, setSelectedBrands] = useState<string[]>([])
  const [minRating, setMinRating] = useState(0)
  const [sortOption, setSortOption] = useState("featured")
  const [filteredProducts, setFilteredProducts] = useState(products)
  const [activeFilters, setActiveFilters] = useState(0)
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false)

  // Get unique categories, colors, and brands
  const categories = [...new Set(products.map((product) => product.category))]
  const colors = [...new Set(products.map((product) => product.color))]
  const brands = [...new Set(products.map((product) => product.brand))]

  // Apply filters and sorting
  useEffect(() => {
    let result = [...products]

    // Search filter
    if (searchQuery) {
      result = result.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Category filter
    if (selectedCategories.length > 0) {
      result = result.filter((product) => selectedCategories.includes(product.category))
    }

    // Color filter
    if (selectedColors.length > 0) {
      result = result.filter((product) => selectedColors.includes(product.color))
    }

    // Brand filter
    if (selectedBrands.length > 0) {
      result = result.filter((product) => selectedBrands.includes(product.brand))
    }

    // Price range filter
    result = result.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Rating filter
    result = result.filter((product) => product.rating >= minRating)

    // Sorting
    switch (sortOption) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-desc":
        result.sort((a, b) => b.price - a.price)
        break
      case "rating":
        result.sort((a, b) => b.rating - a.rating)
        break
      case "newest":
        result.sort((a, b) => (a.isNew ? -1 : 1))
        break
      default:
        // Featured - no specific sorting
        break
    }

    setFilteredProducts(result)

    // Count active filters
    let filterCount = 0
    if (selectedCategories.length > 0) filterCount++
    if (selectedColors.length > 0) filterCount++
    if (selectedBrands.length > 0) filterCount++
    if (priceRange[0] > 0 || priceRange[1] < 200) filterCount++
    if (minRating > 0) filterCount++
    setActiveFilters(filterCount)
  }, [searchQuery, selectedCategories, selectedColors, selectedBrands, priceRange, minRating, sortOption])

  const handleCategoryChange = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const handleColorChange = (color: string) => {
    setSelectedColors((prev) => (prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]))
  }

  const handleBrandChange = (brand: string) => {
    setSelectedBrands((prev) => (prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]))
  }

  const clearAllFilters = () => {
    setSearchQuery("")
    setPriceRange([0, 200])
    setSelectedCategories([])
    setSelectedColors([])
    setSelectedBrands([])
    setMinRating(0)
    setSortOption("featured")
  }

  const removeFilter = (type: string, value?: string) => {
    switch (type) {
      case "category":
        setSelectedCategories((prev) => prev.filter((category) => category !== value))
        break
      case "color":
        setSelectedColors((prev) => prev.filter((color) => color !== value))
        break
      case "brand":
        setSelectedBrands((prev) => prev.filter((brand) => brand !== value))
        break
      case "price":
        setPriceRange([0, 200])
        break
      case "rating":
        setMinRating(0)
        break
      default:
        break
    }
  }

  // Format price for display
  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`
  }

  // Render star rating
  const renderRating = (rating: number) => {
    return (
      <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
          <svg
            key={i}
            className={`w-4 h-4 ${
              i < Math.floor(rating)
                ? "text-amber-500 fill-amber-500"
                : i < rating
                  ? "text-amber-500 fill-amber-500"
                  : "text-gray-300 fill-gray-300"
            }`}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
          >
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
          </svg>
        ))}
        <span className="ml-1 text-sm text-gray-500">{rating.toFixed(1)}</span>
      </div>
    )
  }

  const FilterSidebar = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Filters</h3>
        <Button variant="outline" size="sm" onClick={clearAllFilters} className="mb-4">
          Clear All
        </Button>
      </div>

      <div>
        <h4 className="font-medium mb-3">Price Range</h4>
        <div className="px-2">
          <Slider
            defaultValue={[0, 200]}
            max={200}
            step={1}
            value={priceRange}
            onValueChange={setPriceRange}
            className="mb-2"
          />
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>{formatPrice(priceRange[0])}</span>
            <span>{formatPrice(priceRange[1])}</span>
          </div>
        </div>
      </div>

      <Separator />

      <div>
        <h4 className="font-medium mb-3">Categories</h4>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category} className="flex items-center">
              <Checkbox
                id={`category-${category}`}
                checked={selectedCategories.includes(category)}
                onCheckedChange={() => handleCategoryChange(category)}
              />
              <Label htmlFor={`category-${category}`} className="ml-2 text-sm font-normal cursor-pointer">
                {category}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h4 className="font-medium mb-3">Colors</h4>
        <div className="space-y-2">
          {colors.map((color) => (
            <div key={color} className="flex items-center">
              <Checkbox
                id={`color-${color}`}
                checked={selectedColors.includes(color)}
                onCheckedChange={() => handleColorChange(color)}
              />
              <Label htmlFor={`color-${color}`} className="ml-2 text-sm font-normal cursor-pointer">
                {color}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h4 className="font-medium mb-3">Brands</h4>
        <div className="space-y-2">
          {brands.map((brand) => (
            <div key={brand} className="flex items-center">
              <Checkbox
                id={`brand-${brand}`}
                checked={selectedBrands.includes(brand)}
                onCheckedChange={() => handleBrandChange(brand)}
              />
              <Label htmlFor={`brand-${brand}`} className="ml-2 text-sm font-normal cursor-pointer">
                {brand}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h4 className="font-medium mb-3">Rating</h4>
        <div className="space-y-2">
          {[4, 3, 2, 1].map((rating) => (
            <div key={rating} className="flex items-center">
              <Checkbox
                id={`rating-${rating}`}
                checked={minRating === rating}
                onCheckedChange={() => setMinRating(minRating === rating ? 0 : rating)}
              />
              <Label htmlFor={`rating-${rating}`} className="ml-2 text-sm font-normal cursor-pointer flex items-center">
                {rating}+ {renderRating(rating).props.children[0]}
              </Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-center">Shop Collection</h1>

        {/* Search Bar */}
        <div className="relative mb-8 max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Search products..."
            className="pl-10 pr-4 py-2 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6"
              onClick={() => setSearchQuery("")}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filter Sidebar - Desktop */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <FilterSidebar />
          </div>

          {/* Filter Button - Mobile */}
          <div className="lg:hidden mb-4">
            <Sheet open={isMobileFilterOpen} onOpenChange={setIsMobileFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full">
                  <SlidersHorizontal className="mr-2 h-4 w-4" />
                  Filters
                  {activeFilters > 0 && (
                    <Badge className="ml-2" variant="secondary">
                      {activeFilters}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[350px]">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                  <SheetDescription>Refine your product search</SheetDescription>
                </SheetHeader>
                <div className="py-4">
                  <FilterSidebar />
                </div>
              </SheetContent>
            </Sheet>
          </div>

          <div className="flex-1">
            {/* Active Filters */}
            {activeFilters > 0 && (
              <div className="mb-6">
                <div className="flex flex-wrap gap-2 items-center">
                  <span className="text-sm font-medium">Active Filters:</span>
                  {selectedCategories.map((category) => (
                    <Badge key={`cat-${category}`} variant="secondary" className="flex items-center gap-1">
                      {category}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeFilter("category", category)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </Badge>
                  ))}
                  {selectedColors.map((color) => (
                    <Badge key={`col-${color}`} variant="secondary" className="flex items-center gap-1">
                      {color}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeFilter("color", color)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </Badge>
                  ))}
                  {selectedBrands.map((brand) => (
                    <Badge key={`brand-${brand}`} variant="secondary" className="flex items-center gap-1">
                      {brand}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeFilter("brand", brand)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </Badge>
                  ))}
                  {(priceRange[0] > 0 || priceRange[1] < 200) && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      {`${formatPrice(priceRange[0])} - ${formatPrice(priceRange[1])}`}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeFilter("price")}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </Badge>
                  )}
                  {minRating > 0 && (
                    <Badge variant="secondary" className="flex items-center gap-1">
                      {`${minRating}+ Rating`}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0 hover:bg-transparent"
                        onClick={() => removeFilter("rating")}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove</span>
                      </Button>
                    </Badge>
                  )}
                </div>
              </div>
            )}

            {/* Sort and Results Count */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
              <p className="text-sm text-muted-foreground mb-2 sm:mb-0">Showing {filteredProducts.length} results</p>
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Product Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300"
                  >
                    <div className="relative">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="w-full h-64 object-cover"
                      />
                      {product.isNew && (
                        <Badge className="absolute top-3 right-3 bg-rose-500 hover:bg-rose-600">New</Badge>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-medium text-lg mb-1 line-clamp-1">{product.name}</h3>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-semibold text-lg">{formatPrice(product.price)}</span>
                        {renderRating(product.rating)}
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        <Badge variant="outline">{product.category}</Badge>
                        <Badge variant="outline">{product.color}</Badge>
                      </div>
                      <Button className="w-full mt-4">Add to Cart</Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium mb-2">No products found</h3>
                <p className="text-muted-foreground mb-4">Try adjusting your filters or search query</p>
                <Button onClick={clearAllFilters}>Clear All Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
